import Ads from '../model/Ads';

export const inform = async (req, res, next) => {
    let info = await Ads.find({"companyId": "6388401ae67487b80351a331"});

    return res.json({info});
};