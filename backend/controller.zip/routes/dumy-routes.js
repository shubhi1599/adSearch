import express from 'express';
import { inform } from '../controller/dumy';

const router = express.Router();

router.get('/',inform);

export default router;